# MeetTrack Pro

Google Meet attendance tracking: Chrome extension (MV3) + Supabase backend. Multi-user: each teacher only sees their own data.

## Layout
- `packages/engine` – roster engine: join/leave/rejoin detection, identity confidence, debounce (pure TypeScript, unit tested)
- `apps/extension` – Chrome extension: content script, IndexedDB outbox, retrying sync, popup login
- `supabase/migrations` – database schema, RLS, `sync_batch` and `recompute_sessions` functions

## Build and test
```bash
cd packages/engine && npm install && npm test
cd ../../apps/extension && npm install && npm test && npm run build
```
Load `apps/extension/dist` in Chrome via `chrome://extensions` -> Developer mode -> Load unpacked.

## Status
See PHASE_PROGRESS.md. Meet DOM selectors (`src/content/selectors.ts`) are unvalidated against a live meeting.
