import { build } from 'esbuild';
import { cpSync, mkdirSync, rmSync } from 'node:fs';

rmSync('dist', { recursive: true, force: true });
mkdirSync('dist', { recursive: true });

await build({
  entryPoints: {
    background: 'src/background/index.ts',
    content: 'src/content/index.ts',
    popup: 'src/popup/popup.ts',
  },
  bundle: true,
  format: 'esm',
  target: 'chrome110',
  outdir: 'dist',
  sourcemap: false,
  minify: false,
  logLevel: 'info',
});

// content scripts cannot be ES modules in MV3: rebuild it as an IIFE
await build({
  entryPoints: { content: 'src/content/index.ts' },
  bundle: true,
  format: 'iife',
  target: 'chrome110',
  outdir: 'dist',
  logLevel: 'silent',
});

cpSync('manifest.json', 'dist/manifest.json');
cpSync('src/popup/popup.html', 'dist/popup.html');
cpSync('src/popup/popup.css', 'dist/popup.css');
console.log('extension built -> dist/');
