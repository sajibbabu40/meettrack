export interface Session {
  access_token: string;
  refresh_token: string;
  expires_at: number; // epoch seconds
  email: string | null;
}

export interface KV {
  get(key: string): Promise<unknown>;
  set(key: string, value: unknown): Promise<void>;
  remove(key: string): Promise<void>;
}

const KEY = 'session';

export class Auth {
  constructor(
    private readonly kv: KV,
    private readonly fetchFn: typeof fetch,
    private readonly url: string,
    private readonly apiKey: string,
    private readonly nowSec: () => number = () => Math.floor(Date.now() / 1000),
  ) {}

  async session(): Promise<Session | null> {
    return ((await this.kv.get(KEY)) as Session | undefined) ?? null;
  }

  async login(email: string, password: string): Promise<{ ok: true } | { ok: false; error: string }> {
    return this.token({ grant_type: 'password' }, { email, password });
  }

  /** Valid access token, refreshing 60s before expiry. null when signed out. */
  async getToken(): Promise<string | null> {
    const s = await this.session();
    if (!s) return null;
    if (s.expires_at - 60 > this.nowSec()) return s.access_token;
    return this.refresh();
  }

  async refresh(): Promise<string | null> {
    const s = await this.session();
    if (!s) return null;
    const r = await this.token({ grant_type: 'refresh_token' }, { refresh_token: s.refresh_token });
    if (!r.ok) return null;
    return (await this.session())?.access_token ?? null;
  }

  async logout(): Promise<void> {
    await this.kv.remove(KEY);
  }

  private async token(
    q: { grant_type: string },
    body: Record<string, string>,
  ): Promise<{ ok: true } | { ok: false; error: string }> {
    let res: Response;
    try {
      res = await this.fetchFn(`${this.url}/auth/v1/token?grant_type=${q.grant_type}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: this.apiKey },
        body: JSON.stringify(body),
      });
    } catch {
      return { ok: false, error: 'network' };
    }
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      // A hard auth failure on refresh means the session is dead.
      if (q.grant_type === 'refresh_token' && (res.status === 400 || res.status === 401)) await this.logout();
      return { ok: false, error: String(json.error_description ?? json.msg ?? json.message ?? `HTTP ${res.status}`) };
    }
    const user = json.user as { email?: string } | undefined;
    await this.kv.set(KEY, {
      access_token: String(json.access_token),
      refresh_token: String(json.refresh_token),
      expires_at: Number(json.expires_at ?? this.nowSec() + Number(json.expires_in ?? 3600)),
      email: user?.email ?? null,
    } satisfies Session);
    return { ok: true };
  }
}
