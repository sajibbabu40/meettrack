import { ENGINE_RESUME_WINDOW_MS, FLUSH_ALARM_MINUTES, FLUSH_BATCH_SIZE, SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from '../config';
import type { Msg, StatusReply } from '../shared/types';
import { Auth, type KV } from './auth';
import { IdbStore } from './store';
import { flush } from './sync';

const store = new IdbStore();

const kv: KV = {
  get: async (k) => (await chrome.storage.local.get(k))[k],
  set: (k, v) => chrome.storage.local.set({ [k]: v }),
  remove: (k) => chrome.storage.local.remove(k),
};
const auth = new Auth(kv, fetch.bind(globalThis), SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

async function runFlush() {
  const r = await flush({
    store,
    fetchFn: fetch.bind(globalThis),
    supabaseUrl: SUPABASE_URL,
    apiKey: SUPABASE_PUBLISHABLE_KEY,
    getToken: () => auth.getToken(),
    refreshToken: () => auth.refresh(),
    batchSize: FLUSH_BATCH_SIZE,
  });
  if (r.status === 'ok') {
    await chrome.storage.local.set({ lastSyncAt: Date.now(), lastError: null });
  } else {
    const lastError =
      r.status === 'rejected' ? (r.error ?? 'rejected') : r.status === 'not_signed_in' ? 'Not signed in' : 'Offline, will retry';
    await chrome.storage.local.set({ lastError });
  }
  return r;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('flush', { periodInMinutes: FLUSH_ALARM_MINUTES });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('flush', { periodInMinutes: FLUSH_ALARM_MINUTES });
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'flush') void runFlush();
});

async function deviceId(): Promise<string> {
  const cur = (await kv.get('deviceId')) as string | undefined;
  if (cur) return cur;
  const id = crypto.randomUUID();
  await kv.set('deviceId', id);
  return id;
}

chrome.runtime.onMessage.addListener((msg: Msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.kind) {
      case 'getEngine': {
        const saved = await store.getEngineByCode(msg.meet_code, ENGINE_RESUME_WINDOW_MS, Date.now());
        sendResponse({ saved, deviceId: await deviceId() });
        return;
      }
      case 'ingest': {
        await store.saveBatch({
          meeting: msg.meeting,
          participants: msg.participants,
          events: msg.events,
          engine: msg.engine,
        });
        sendResponse({ ok: true });
        if (msg.flushNow) await runFlush();
        else if (msg.events.length) setTimeout(() => void runFlush(), 3000);
        return;
      }
      case 'login': {
        const r = await auth.login(msg.email, msg.password);
        if (r.ok) void runFlush();
        sendResponse(r);
        return;
      }
      case 'logout':
        await auth.logout();
        sendResponse({ ok: true });
        return;
      case 'flush': {
        sendResponse(await runFlush());
        return;
      }
      case 'status': {
        const s = await auth.session();
        const stored = await chrome.storage.local.get(['lastSyncAt', 'lastError']);
        const reply: StatusReply = {
          signedIn: !!s,
          email: s?.email ?? null,
          pendingEvents: await store.countPendingEvents(),
          lastSyncAt: (stored.lastSyncAt as number | undefined) ?? null,
          lastError: (stored.lastError as string | undefined) ?? null,
        };
        sendResponse(reply);
        return;
      }
    }
  })();
  return true; // async response
});
