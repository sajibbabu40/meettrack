import type { MeetingRecord, OutboxEvent, ParticipantRecord, PendingGroup, SavedEngine } from '../shared/types';

/** Durable local buffer. Events are keyed by event_id so re-saving is idempotent. */
export interface Store {
  saveBatch(input: {
    meeting: Omit<MeetingRecord, 'dirty' | 'rev'>;
    participants: ParticipantRecord[];
    events: OutboxEvent[];
    engine: SavedEngine;
  }): Promise<void>;
  getEngineByCode(meetCode: string, maxAgeMs: number, now: number): Promise<SavedEngine | null>;
  listPending(): Promise<PendingGroup[]>;
  markSynced(clientMeetingId: string, eventIds: string[], rev: number): Promise<void>;
  countPendingEvents(): Promise<number>;
}

export class MemoryStore implements Store {
  meetings = new Map<string, MeetingRecord>();
  participants = new Map<string, ParticipantRecord>();
  events = new Map<string, OutboxEvent>();
  engines = new Map<string, SavedEngine>();

  async saveBatch(i: Parameters<Store['saveBatch']>[0]): Promise<void> {
    const prev = this.meetings.get(i.meeting.client_meeting_id);
    this.meetings.set(i.meeting.client_meeting_id, { ...i.meeting, dirty: true, rev: (prev?.rev ?? 0) + 1 });
    for (const p of i.participants) this.participants.set(p.client_participant_id, p);
    for (const e of i.events) this.events.set(e.event_id, e);
    this.engines.set(i.engine.client_meeting_id, i.engine);
  }

  async getEngineByCode(code: string, maxAgeMs: number, now: number): Promise<SavedEngine | null> {
    let best: SavedEngine | null = null;
    for (const e of this.engines.values()) {
      if (e.meet_code !== code || now - e.updated_at > maxAgeMs || e.state.ended) continue;
      if (!best || e.updated_at > best.updated_at) best = e;
    }
    return best;
  }

  async listPending(): Promise<PendingGroup[]> {
    const out: PendingGroup[] = [];
    for (const m of this.meetings.values()) {
      const events = [...this.events.values()].filter((e) => e.client_meeting_id === m.client_meeting_id);
      if (!m.dirty && events.length === 0) continue;
      const participants = [...this.participants.values()].filter((p) => p.client_meeting_id === m.client_meeting_id);
      out.push({ meeting: m, participants, events });
    }
    return out;
  }

  async markSynced(id: string, eventIds: string[], rev: number): Promise<void> {
    for (const eid of eventIds) this.events.delete(eid);
    const m = this.meetings.get(id);
    if (m && m.rev === rev) m.dirty = false;
  }

  async countPendingEvents(): Promise<number> {
    return this.events.size;
  }
}

const DB_NAME = 'meettrack';
const STORES = ['meetings', 'participants', 'events', 'engines'] as const;

function reqP<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((res, rej) => {
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
    tx.onabort = () => rej(tx.error);
  });
}

/** IndexedDB-backed store (lives in the extension origin, survives browser restarts). */
export class IdbStore implements Store {
  private dbp: Promise<IDBDatabase> | null = null;
  constructor(private readonly factory: IDBFactory = indexedDB, private readonly name = DB_NAME) {}

  private db(): Promise<IDBDatabase> {
    if (!this.dbp) {
      this.dbp = new Promise((res, rej) => {
        const open = this.factory.open(this.name, 1);
        open.onupgradeneeded = () => {
          const db = open.result;
          db.createObjectStore('meetings', { keyPath: 'client_meeting_id' });
          db.createObjectStore('participants', { keyPath: 'client_participant_id' });
          db.createObjectStore('events', { keyPath: 'event_id' });
          db.createObjectStore('engines', { keyPath: 'client_meeting_id' });
        };
        open.onsuccess = () => res(open.result);
        open.onerror = () => rej(open.error);
      });
    }
    return this.dbp;
  }

  async saveBatch(i: Parameters<Store['saveBatch']>[0]): Promise<void> {
    const db = await this.db();
    const tx = db.transaction([...STORES], 'readwrite');
    const prev = (await reqP(tx.objectStore('meetings').get(i.meeting.client_meeting_id))) as MeetingRecord | undefined;
    tx.objectStore('meetings').put({ ...i.meeting, dirty: true, rev: (prev?.rev ?? 0) + 1 });
    for (const p of i.participants) tx.objectStore('participants').put(p);
    for (const e of i.events) tx.objectStore('events').put(e);
    tx.objectStore('engines').put(i.engine);
    await txDone(tx);
  }

  async getEngineByCode(code: string, maxAgeMs: number, now: number): Promise<SavedEngine | null> {
    const db = await this.db();
    const all = (await reqP(db.transaction('engines').objectStore('engines').getAll())) as SavedEngine[];
    let best: SavedEngine | null = null;
    for (const e of all) {
      if (e.meet_code !== code || now - e.updated_at > maxAgeMs || e.state.ended) continue;
      if (!best || e.updated_at > best.updated_at) best = e;
    }
    return best;
  }

  async listPending(): Promise<PendingGroup[]> {
    const db = await this.db();
    const tx = db.transaction(['meetings', 'participants', 'events']);
    const meetings = (await reqP(tx.objectStore('meetings').getAll())) as MeetingRecord[];
    const participants = (await reqP(tx.objectStore('participants').getAll())) as ParticipantRecord[];
    const events = (await reqP(tx.objectStore('events').getAll())) as OutboxEvent[];
    const out: PendingGroup[] = [];
    for (const m of meetings) {
      const ev = events.filter((e) => e.client_meeting_id === m.client_meeting_id);
      if (!m.dirty && ev.length === 0) continue;
      out.push({
        meeting: m,
        participants: participants.filter((p) => p.client_meeting_id === m.client_meeting_id),
        events: ev,
      });
    }
    return out;
  }

  async markSynced(id: string, eventIds: string[], rev: number): Promise<void> {
    const db = await this.db();
    const tx = db.transaction(['meetings', 'events'], 'readwrite');
    for (const eid of eventIds) tx.objectStore('events').delete(eid);
    const m = (await reqP(tx.objectStore('meetings').get(id))) as MeetingRecord | undefined;
    if (m && m.rev === rev) tx.objectStore('meetings').put({ ...m, dirty: false });
    await txDone(tx);
  }

  async countPendingEvents(): Promise<number> {
    const db = await this.db();
    return reqP(db.transaction('events').objectStore('events').count());
  }
}
