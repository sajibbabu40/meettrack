import type { PendingGroup } from '../shared/types';
import type { Store } from './store';

export interface SyncDeps {
  store: Store;
  fetchFn: typeof fetch;
  supabaseUrl: string;
  apiKey: string;
  /** Returns a valid access token, refreshing if needed. null = not signed in. */
  getToken: () => Promise<string | null>;
  /** Force a refresh after a 401. Returns new token or null. */
  refreshToken: () => Promise<string | null>;
  batchSize: number;
}

export interface FlushResult {
  sentEvents: number;
  groups: number;
  status: 'ok' | 'not_signed_in' | 'network_error' | 'rejected';
  error?: string;
}

export function buildPayload(group: PendingGroup, events = group.events) {
  const m = group.meeting;
  return {
    meeting: {
      client_meeting_id: m.client_meeting_id,
      meet_code: m.meet_code,
      title: m.title ?? null,
      started_at: m.started_at,
      ended_at: m.ended_at ?? null,
      status: m.status,
    },
    participants: group.participants.map((p) => ({
      client_participant_id: p.client_participant_id,
      display_name: p.display_name,
      identity_confidence: p.identity_confidence,
      identity_signals: p.identity_signals,
    })),
    events: events.map((e) => ({
      event_id: e.event_id,
      client_participant_id: e.client_participant_id,
      event_type: e.event_type,
      occurred_at: e.occurred_at,
      device_id: e.device_id,
    })),
  };
}

type Post = { kind: 'ok' } | { kind: 'unauthorized' } | { kind: 'network' } | { kind: 'rejected'; msg: string };

async function post(deps: SyncDeps, token: string, payload: unknown): Promise<Post> {
  let res: Response;
  try {
    res = await deps.fetchFn(`${deps.supabaseUrl}/rest/v1/rpc/sync_batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: deps.apiKey, Authorization: `Bearer ${token}` },
      body: JSON.stringify({ payload }),
    });
  } catch {
    return { kind: 'network' };
  }
  if (res.ok) return { kind: 'ok' };
  if (res.status === 401) return { kind: 'unauthorized' };
  // Server trouble / throttling: retry later, keep data.
  if (res.status >= 500 || res.status === 408 || res.status === 429) return { kind: 'network' };
  let msg = `HTTP ${res.status}`;
  try {
    const body = (await res.json()) as { message?: string };
    if (body.message) msg = body.message;
  } catch {
    /* ignore */
  }
  return { kind: 'rejected', msg };
}

/**
 * Sends everything pending. Safe to call repeatedly: the server dedupes by event_id,
 * and local rows are only removed after a confirmed 2xx.
 */
export async function flush(deps: SyncDeps): Promise<FlushResult> {
  let token = await deps.getToken();
  if (!token) return { sentEvents: 0, groups: 0, status: 'not_signed_in' };

  const groups = await deps.store.listPending();
  let sent = 0;
  let done = 0;
  let firstRejection: string | undefined;

  for (const g of groups) {
    const chunks: PendingGroup['events'][] = [];
    for (let i = 0; i < g.events.length; i += deps.batchSize) chunks.push(g.events.slice(i, i + deps.batchSize));
    if (chunks.length === 0) chunks.push([]); // meeting/participant metadata only

    let groupOk = true;
    for (const chunk of chunks) {
      const payload = buildPayload(g, chunk);
      let r = await post(deps, token, payload);
      if (r.kind === 'unauthorized') {
        const fresh = await deps.refreshToken();
        if (!fresh) return { sentEvents: sent, groups: done, status: 'not_signed_in' };
        token = fresh;
        r = await post(deps, token, payload);
      }
      if (r.kind === 'network' || r.kind === 'unauthorized') {
        return {
          sentEvents: sent,
          groups: done,
          status: 'network_error',
          error: r.kind === 'unauthorized' ? 'unauthorized' : undefined,
        };
      }
      if (r.kind === 'rejected') {
        firstRejection ??= r.msg;
        groupOk = false;
        break; // keep this meeting's data locally; try the next meeting
      }
      await deps.store.markSynced(g.meeting.client_meeting_id, chunk.map((e) => e.event_id), g.meeting.rev);
      sent += chunk.length;
    }
    if (groupOk) done += 1;
  }
  return firstRejection
    ? { sentEvents: sent, groups: done, status: 'rejected', error: firstRejection }
    : { sentEvents: sent, groups: done, status: 'ok' };
}
