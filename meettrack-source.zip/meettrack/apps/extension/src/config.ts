// Publishable (public) values only. Never put service-role keys in the extension.
export const SUPABASE_URL = 'https://gymuryijpeobjsorgwlt.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_epfbOdsadl5rSo_-5OzA7Q_Vt9l8VXS';
export const FLUSH_BATCH_SIZE = 500;
export const FLUSH_ALARM_MINUTES = 1;
export const ENGINE_RESUME_WINDOW_MS = 6 * 60 * 60 * 1000;
