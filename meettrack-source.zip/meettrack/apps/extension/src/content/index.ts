import { RosterEngine, type EngineEvent } from '@meettrack/engine';
import type { OutboxEvent, ParticipantRecord, SavedEngine } from '../shared/types';
import { meetCodeFromPath, readRoster } from './selectors';

const TICK_MS = 5000;
const MUTATION_DEBOUNCE_MS = 1500;

let engine: RosterEngine | null = null;
let meta: { clientMeetingId: string; meetCode: string; startedAt: string; deviceId: string } | null = null;
let busy = false;
let ended = false;
let lastSig = '';

function send<T>(msg: unknown): Promise<T | undefined> {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        void chrome.runtime.lastError; // service worker may be waking up; swallow
        resolve(r as T | undefined);
      });
    } catch {
      resolve(undefined);
    }
  });
}

function toOutbox(ev: EngineEvent): OutboxEvent {
  return {
    event_id: ev.event_id,
    client_meeting_id: meta!.clientMeetingId,
    client_participant_id: ev.participant_id,
    event_type: ev.type,
    occurred_at: ev.occurred_at,
    device_id: meta!.deviceId,
  };
}

function participantRecords(): ParticipantRecord[] {
  return engine!.getParticipants().map((p) => ({
    client_participant_id: p.id,
    client_meeting_id: meta!.clientMeetingId,
    display_name: p.name,
    identity_confidence: p.confidence,
    identity_signals: { hasDeviceId: !!p.deviceId, hasAvatar: !!p.avatar, duplicateName: p.duplicateName },
  }));
}

async function persist(events: EngineEvent[], status: 'live' | 'ended', flushNow = false) {
  const saved: SavedEngine = {
    client_meeting_id: meta!.clientMeetingId,
    meet_code: meta!.meetCode,
    state: engine!.snapshot(),
    updated_at: Date.now(),
  };
  const endEvent = events.find((e) => e.type === 'meeting_end');
  await send({
    kind: 'ingest',
    meeting: {
      client_meeting_id: meta!.clientMeetingId,
      meet_code: meta!.meetCode,
      started_at: meta!.startedAt,
      ended_at: endEvent?.occurred_at ?? null,
      status,
    },
    participants: participantRecords(),
    events: events.map(toOutbox),
    engine: saved,
    flushNow,
  });
}

async function init(meetCode: string) {
  const reply = await send<{ saved: SavedEngine | null; deviceId: string }>({ kind: 'getEngine', meet_code: meetCode });
  if (!reply) return false;
  engine = new RosterEngine();
  let startEvents: EngineEvent[] = [];
  if (reply.saved) {
    // Resume after a tab reload / extension restart: same meeting, same participants.
    engine.restore(reply.saved.state);
    meta = {
      clientMeetingId: reply.saved.client_meeting_id,
      meetCode,
      startedAt: new Date(reply.saved.updated_at).toISOString(),
      deviceId: reply.deviceId,
    };
  } else {
    meta = { clientMeetingId: crypto.randomUUID(), meetCode, startedAt: new Date().toISOString(), deviceId: reply.deviceId };
    startEvents = engine.start(Date.now());
  }
  await persist(startEvents, 'live');
  return true;
}

async function tick() {
  if (busy || ended || !engine || !meta) return;
  busy = true;
  try {
    const { entries, source } = readRoster(document);
    const events = engine.ingest(entries, Date.now(), source !== 'none', source === 'tiles');
    const sig = JSON.stringify(engine.getParticipants().map((p) => [p.id, p.confidence, p.name]));
    if (events.length > 0 || sig !== lastSig) {
      lastSig = sig;
      await persist(events, 'live');
    }
  } finally {
    busy = false;
  }
}

async function finish() {
  if (ended || !engine || !meta) return;
  ended = true;
  await persist(engine.end(Date.now()), 'ended', true);
}

async function main() {
  const code = meetCodeFromPath(location.pathname);
  if (!code) return;
  if (!(await init(code))) return;

  let timer: number | undefined;
  new MutationObserver(() => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => void tick(), MUTATION_DEBOUNCE_MS);
  }).observe(document.body, { childList: true, subtree: true });
  window.setInterval(() => void tick(), TICK_MS);

  window.addEventListener('pagehide', () => void finish());
  // Meet is a single-page app: leaving the call changes the path without a reload.
  let path = location.pathname;
  window.setInterval(() => {
    if (location.pathname !== path) {
      path = location.pathname;
      if (meetCodeFromPath(path) !== code) void finish();
    }
  }, 2000);
}

void main();
