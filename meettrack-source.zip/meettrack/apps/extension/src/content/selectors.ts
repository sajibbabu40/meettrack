import type { RosterEntry } from '@meettrack/engine';

/**
 * All Meet-specific DOM knowledge lives here, in one place, so it can be updated
 * quickly when Google changes its markup. Each list is tried in order.
 * NOTE: these selectors are best-effort and MUST be validated against a live Meet session.
 */
export const SELECTORS = {
  panelList: [
    '[role="list"][aria-label*="articipant" i]',
    '[role="list"][aria-label*="people" i]',
  ],
  panelItem: '[role="listitem"]',
  tile: '[data-participant-id]',
  nameAttr: 'data-self-name',
} as const;

export type ReadSource = 'panel' | 'tiles' | 'none';
export interface ReadResult {
  entries: RosterEntry[];
  source: ReadSource;
}

function cleanAvatar(src: string | null | undefined): string | null {
  if (!src) return null;
  try {
    const u = new URL(src, 'https://meet.google.com');
    return u.origin + u.pathname; // drop size/query params that change between renders
  } catch {
    return src.split('?')[0] ?? null;
  }
}

function itemName(el: Element): string {
  const attr = el.querySelector(`[${SELECTORS.nameAttr}]`)?.getAttribute(SELECTORS.nameAttr);
  if (attr?.trim()) return attr.trim();
  const label = el.getAttribute('aria-label');
  if (label?.trim()) return label.trim();
  for (const span of Array.from(el.querySelectorAll('span'))) {
    const t = span.textContent?.trim();
    if (t) return t;
  }
  return (el.textContent ?? '').trim().split('\n')[0]?.trim() ?? '';
}

function entryFrom(el: Element): RosterEntry | null {
  const name = itemName(el);
  if (!name) return null;
  const idEl = el.hasAttribute('data-participant-id') ? el : el.querySelector('[data-participant-id]');
  return {
    name,
    deviceId: idEl?.getAttribute('data-participant-id') ?? null,
    avatar: cleanAvatar(el.querySelector('img')?.getAttribute('src')),
  };
}

/**
 * Reads the roster. The participants panel lists everyone (authoritative, 'panel');
 * video tiles only show who is visible ('tiles', partial: never used to infer leaves).
 */
export function readRoster(doc: Document): ReadResult {
  for (const sel of SELECTORS.panelList) {
    const list = doc.querySelector(sel);
    if (!list) continue;
    const entries = Array.from(list.querySelectorAll(SELECTORS.panelItem))
      .map(entryFrom)
      .filter((e): e is RosterEntry => e !== null);
    if (entries.length > 0) return { entries, source: 'panel' };
  }
  const seen = new Set<string>();
  const tiles: RosterEntry[] = [];
  for (const el of Array.from(doc.querySelectorAll(SELECTORS.tile))) {
    const id = el.getAttribute('data-participant-id');
    if (!id || seen.has(id)) continue;
    seen.add(id);
    const e = entryFrom(el);
    if (e) tiles.push(e);
  }
  return tiles.length > 0 ? { entries: tiles, source: 'tiles' } : { entries: [], source: 'none' };
}

export const MEET_CODE_RE = /^\/([a-z]{3}-[a-z]{4}-[a-z]{3})\/?$/;

export function meetCodeFromPath(pathname: string): string | null {
  return MEET_CODE_RE.exec(pathname)?.[1] ?? null;
}
