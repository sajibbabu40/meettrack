import type { StatusReply } from '../shared/types';

const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;

function call<T>(msg: unknown): Promise<T> {
  return new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r as T)));
}

async function render() {
  const s = await call<StatusReply>({ kind: 'status' });
  $('login').hidden = s.signedIn;
  $('main').hidden = !s.signedIn;
  if (!s.signedIn) return;
  $('who').textContent = s.email ?? '';
  $('pending').textContent = String(s.pendingEvents);
  $('last').textContent = s.lastSyncAt ? new Date(s.lastSyncAt).toLocaleTimeString() : 'never';
  $('status').textContent = s.lastError ?? '';
}

$('loginBtn').addEventListener('click', async () => {
  const btn = $<HTMLButtonElement>('loginBtn');
  btn.disabled = true;
  $('loginErr').textContent = '';
  const r = await call<{ ok: boolean; error?: string }>({
    kind: 'login',
    email: $<HTMLInputElement>('email').value.trim(),
    password: $<HTMLInputElement>('password').value,
  });
  btn.disabled = false;
  if (!r.ok) $('loginErr').textContent = r.error === 'network' ? 'No connection. Try again.' : (r.error ?? 'Sign-in failed');
  else $<HTMLInputElement>('password').value = '';
  await render();
});

$('syncBtn').addEventListener('click', async () => {
  const btn = $<HTMLButtonElement>('syncBtn');
  btn.disabled = true;
  await call({ kind: 'flush' });
  btn.disabled = false;
  await render();
});

$('logoutBtn').addEventListener('click', async () => {
  await call({ kind: 'logout' });
  await render();
});

void render();
