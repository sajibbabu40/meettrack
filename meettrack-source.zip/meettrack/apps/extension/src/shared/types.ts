import type { EngineState } from '@meettrack/engine';

export interface MeetingRecord {
  client_meeting_id: string;
  meet_code: string;
  title?: string | null;
  started_at: string;
  ended_at?: string | null;
  status: 'live' | 'ended' | 'interrupted';
  /** true when the server has not yet seen the latest version */
  dirty: boolean;
  /** increments on every local change; lets a flush know if newer data arrived meanwhile */
  rev: number;
}

export interface ParticipantRecord {
  client_participant_id: string;
  client_meeting_id: string;
  display_name: string;
  identity_confidence: 'high' | 'medium' | 'low' | 'uncertain';
  identity_signals: Record<string, unknown>;
}

export interface OutboxEvent {
  event_id: string;
  client_meeting_id: string;
  client_participant_id: string | null;
  event_type: 'meeting_start' | 'join' | 'leave' | 'seen' | 'meeting_end';
  occurred_at: string;
  device_id: string;
}

export interface SavedEngine {
  client_meeting_id: string;
  meet_code: string;
  state: EngineState;
  updated_at: number;
}

export interface PendingGroup {
  meeting: MeetingRecord;
  participants: ParticipantRecord[];
  events: OutboxEvent[];
}

/** Messages sent from the content script / popup to the service worker. */
export type Msg =
  | { kind: 'getEngine'; meet_code: string }
  | {
      kind: 'ingest';
      meeting: Omit<MeetingRecord, 'dirty' | 'rev'>;
      participants: ParticipantRecord[];
      events: OutboxEvent[];
      engine: SavedEngine;
      flushNow?: boolean;
    }
  | { kind: 'status' }
  | { kind: 'login'; email: string; password: string }
  | { kind: 'logout' }
  | { kind: 'flush' };

export interface StatusReply {
  signedIn: boolean;
  email: string | null;
  pendingEvents: number;
  lastSyncAt: number | null;
  lastError: string | null;
}
