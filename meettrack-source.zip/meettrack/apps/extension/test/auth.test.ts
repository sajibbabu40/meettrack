import { describe, expect, it } from 'vitest';
import { Auth, type KV } from '../src/background/auth';

function mem(): KV & { data: Map<string, unknown> } {
  const data = new Map<string, unknown>();
  return { data, get: async (k) => data.get(k), set: async (k, v) => void data.set(k, v), remove: async (k) => void data.delete(k) };
}
const tokenRes = (n: number, exp: number) =>
  new Response(JSON.stringify({ access_token: 'a' + n, refresh_token: 'r' + n, expires_at: exp, user: { email: 'a@b.c' } }), { status: 200 });

describe('Auth', () => {
  it('stores the session on login and returns the cached token while valid', async () => {
    const kv = mem(); let calls = 0;
    const a = new Auth(kv, (async () => { calls++; return tokenRes(1, 10_000); }) as typeof fetch, 'https://x', 'k', () => 1000);
    expect(await a.login('a@b.c', 'pw')).toEqual({ ok: true });
    expect(await a.getToken()).toBe('a1');
    expect(calls).toBe(1);
  });

  it('refreshes shortly before expiry', async () => {
    const kv = mem(); let n = 0; let now = 1000;
    const a = new Auth(kv, (async () => tokenRes(++n, now + 3600)) as typeof fetch, 'https://x', 'k', () => now);
    await a.login('a@b.c', 'pw');
    now += 3560; // within the 60s safety margin
    expect(await a.getToken()).toBe('a2');
  });

  it('signs out when the refresh token is rejected', async () => {
    const kv = mem(); let first = true; const now = 1000;
    const a = new Auth(kv, (async () => { if (first) { first = false; return tokenRes(1, now + 10); } return new Response('{"error_description":"bad"}', { status: 400 }); }) as typeof fetch, 'https://x', 'k', () => now);
    await a.login('a@b.c', 'pw');
    expect(await a.getToken()).toBeNull();
    expect(await a.session()).toBeNull();
  });

  it('reports wrong credentials without storing anything', async () => {
    const kv = mem();
    const a = new Auth(kv, (async () => new Response('{"error_description":"Invalid login credentials"}', { status: 400 })) as typeof fetch, 'https://x', 'k');
    expect(await a.login('a@b.c', 'bad')).toEqual({ ok: false, error: 'Invalid login credentials' });
    expect(kv.data.size).toBe(0);
  });
});
