import type { OutboxEvent } from '../src/shared/types';
import type { Store } from '../src/background/store';

export const MID = '11111111-1111-4111-8111-111111111111';
export const PID = '22222222-2222-4222-8222-222222222222';

export function ev(i: number, type: OutboxEvent['event_type'] = 'join'): OutboxEvent {
  return {
    event_id: `00000000-0000-4000-8000-${String(i).padStart(12, '0')}`,
    client_meeting_id: MID,
    client_participant_id: PID,
    event_type: type,
    occurred_at: new Date(1_700_000_000_000 + i * 1000).toISOString(),
    device_id: '33333333-3333-4333-8333-333333333333',
  };
}

export async function seed(store: Store, events: OutboxEvent[], status: 'live' | 'ended' = 'live') {
  await store.saveBatch({
    meeting: { client_meeting_id: MID, meet_code: 'abc-defg-hij', started_at: new Date(1_700_000_000_000).toISOString(), status },
    participants: [
      { client_participant_id: PID, client_meeting_id: MID, display_name: 'Rahim', identity_confidence: 'low', identity_signals: {} },
    ],
    events,
    engine: {
      client_meeting_id: MID,
      meet_code: 'abc-defg-hij',
      updated_at: 1_700_000_000_000,
      state: { participants: [], started: true, ended: false },
    },
  });
}
