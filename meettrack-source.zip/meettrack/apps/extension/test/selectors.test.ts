// @vitest-environment jsdom
import { describe, expect, it } from 'vitest';
import { meetCodeFromPath, readRoster } from '../src/content/selectors';

const html = (s: string) => { document.body.innerHTML = s; return document; };

describe('readRoster (synthetic DOM, NOT a live Meet validation)', () => {
  it('reads the participants panel as the authoritative source', () => {
    const r = readRoster(html(`
      <div role="list" aria-label="Participants">
        <div role="listitem" aria-label="Rahim" data-participant-id="spaces/x/devices/1"><img src="https://lh3.x/a.jpg?sz=64"></div>
        <div role="listitem"><span>Karim (You)</span></div>
      </div>`));
    expect(r.source).toBe('panel');
    expect(r.entries.map((e) => e.name)).toEqual(['Rahim', 'Karim (You)']);
    expect(r.entries[0]).toMatchObject({ deviceId: 'spaces/x/devices/1', avatar: 'https://lh3.x/a.jpg' });
  });

  it('falls back to video tiles and flags them as partial', () => {
    const r = readRoster(html(`
      <div data-participant-id="p1"><div data-self-name="Rahim"></div></div>
      <div data-participant-id="p1"><div data-self-name="Rahim"></div></div>
      <div data-participant-id="p2"><div data-self-name="Karim"></div></div>`));
    expect(r.source).toBe('tiles');
    expect(r.entries).toHaveLength(2); // duplicate tile for same id collapsed
  });

  it('returns source none when nothing recognisable is present (engine will ignore the snapshot)', () => {
    expect(readRoster(html('<div>lobby</div>'))).toEqual({ entries: [], source: 'none' });
  });

  it('only treats real meeting-code paths as meetings', () => {
    expect(meetCodeFromPath('/abc-defg-hij')).toBe('abc-defg-hij');
    expect(meetCodeFromPath('/abc-defg-hij/')).toBe('abc-defg-hij');
    expect(meetCodeFromPath('/landing')).toBeNull();
    expect(meetCodeFromPath('/')).toBeNull();
  });
});
