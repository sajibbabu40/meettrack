import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { IdbStore, MemoryStore, type Store } from '../src/background/store';
import { MID, ev, seed } from './helpers';

const impls: [string, () => Store][] = [
  ['MemoryStore', () => new MemoryStore()],
  ['IdbStore', () => new IdbStore(indexedDB, 'test-' + Math.random())],
];

describe.each(impls)('%s contract', (_n, make) => {
  it('saving the same event twice keeps one copy (idempotent buffer)', async () => {
    const s = make();
    await seed(s, [ev(1), ev(2)]);
    await seed(s, [ev(2), ev(3)]);
    expect(await s.countPendingEvents()).toBe(3);
  });

  it('markSynced removes events and clears dirty only if no newer revision arrived', async () => {
    const s = make();
    await seed(s, [ev(1)]);
    const [g1] = await s.listPending();
    await seed(s, [ev(2)]); // newer data arrives while "flush" is in flight
    await s.markSynced(MID, [ev(1).event_id], g1!.meeting.rev);
    const [g2] = await s.listPending();
    expect(g2!.events.map((e) => e.event_id)).toEqual([ev(2).event_id]);
    expect(g2!.meeting.dirty).toBe(true);
    await s.markSynced(MID, [ev(2).event_id], g2!.meeting.rev);
    expect(await s.listPending()).toEqual([]);
  });

  it('finds the latest un-ended engine state for a meet code within the window', async () => {
    const s = make();
    await seed(s, [ev(1)]);
    const now = 1_700_000_000_000 + 60_000;
    expect((await s.getEngineByCode('abc-defg-hij', 3_600_000, now))?.client_meeting_id).toBe(MID);
    expect(await s.getEngineByCode('zzz-zzzz-zzz', 3_600_000, now)).toBeNull();
    expect(await s.getEngineByCode('abc-defg-hij', 1000, now)).toBeNull(); // too old
  });
});
