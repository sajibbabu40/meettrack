import { describe, expect, it } from 'vitest';
import { MemoryStore } from '../src/background/store';
import { buildPayload, flush, type SyncDeps } from '../src/background/sync';
import { ev, seed } from './helpers';

function deps(store: MemoryStore, fetchFn: typeof fetch, over: Partial<SyncDeps> = {}): SyncDeps {
  return {
    store, fetchFn, supabaseUrl: 'https://x.supabase.co', apiKey: 'k',
    getToken: async () => 'tok', refreshToken: async () => 'tok2', batchSize: 2, ...over,
  };
}
const ok = () => new Response('{}', { status: 200 });

describe('flush', () => {
  it('does nothing and keeps data when signed out', async () => {
    const s = new MemoryStore();
    await seed(s, [ev(1)]);
    const r = await flush(deps(s, (async () => ok()) as typeof fetch, { getToken: async () => null }));
    expect(r.status).toBe('not_signed_in');
    expect(await s.countPendingEvents()).toBe(1);
  });

  it('keeps every event when the network fails, then delivers after recovery', async () => {
    const s = new MemoryStore();
    await seed(s, [ev(1), ev(2), ev(3)]);
    const down = (async () => { throw new TypeError('offline'); }) as typeof fetch;
    expect((await flush(deps(s, down))).status).toBe('network_error');
    expect(await s.countPendingEvents()).toBe(3);

    const bodies: unknown[] = [];
    const up = (async (_u: string, init: RequestInit) => { bodies.push(JSON.parse(String(init.body))); return ok(); }) as typeof fetch;
    const r = await flush(deps(s, up));
    expect(r).toMatchObject({ status: 'ok', sentEvents: 3 });
    expect(bodies).toHaveLength(2); // 3 events, batch size 2
    expect(await s.countPendingEvents()).toBe(0);
    expect(await s.listPending()).toEqual([]);
  });

  it('treats 5xx and 429 as retryable (data kept)', async () => {
    for (const status of [500, 503, 429]) {
      const s = new MemoryStore();
      await seed(s, [ev(1)]);
      const r = await flush(deps(s, (async () => new Response('', { status })) as typeof fetch));
      expect(r.status).toBe('network_error');
      expect(await s.countPendingEvents()).toBe(1);
    }
  });

  it('refreshes the token once on 401 and retries', async () => {
    const s = new MemoryStore();
    await seed(s, [ev(1)]);
    const seen: string[] = [];
    const f = (async (_u: string, init: RequestInit) => {
      const auth = (init.headers as Record<string, string>).Authorization!;
      seen.push(auth);
      return auth === 'Bearer tok' ? new Response('', { status: 401 }) : ok();
    }) as typeof fetch;
    const r = await flush(deps(s, f));
    expect(r.status).toBe('ok');
    expect(seen).toEqual(['Bearer tok', 'Bearer tok2']);
  });

  it('keeps data and reports the server message on a hard rejection (e.g. quota)', async () => {
    const s = new MemoryStore();
    await seed(s, [ev(1)]);
    const f = (async () => new Response(JSON.stringify({ message: 'monthly meeting limit reached' }), { status: 400 })) as typeof fetch;
    const r = await flush(deps(s, f));
    expect(r).toMatchObject({ status: 'rejected', error: 'monthly meeting limit reached' });
    expect(await s.countPendingEvents()).toBe(1);
  });

  it('sends metadata-only groups (meeting/participants changed, no events)', async () => {
    const s = new MemoryStore();
    await seed(s, []);
    let calls = 0;
    const r = await flush(deps(s, (async () => { calls++; return ok(); }) as typeof fetch));
    expect(r.status).toBe('ok');
    expect(calls).toBe(1);
    expect(await s.listPending()).toEqual([]);
  });

  it('payload carries only the fields the server function expects', async () => {
    const s = new MemoryStore();
    await seed(s, [ev(1)]);
    const [g] = await s.listPending();
    const p = buildPayload(g!);
    expect(Object.keys(p).sort()).toEqual(['events', 'meeting', 'participants']);
    expect(Object.keys(p.events[0]!).sort()).toEqual(['client_participant_id', 'device_id', 'event_id', 'event_type', 'occurred_at']);
  });
});
