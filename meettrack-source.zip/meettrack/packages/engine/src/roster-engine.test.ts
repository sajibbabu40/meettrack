import { describe, expect, it } from 'vitest';
import { RosterEngine, normalizeName, type EngineEvent } from './roster-engine';

let n = 0;
const mk = () => new RosterEngine({ uuid: () => `id-${++n}`, leaveAfterMisses: 2, seenIntervalMs: 30_000 });
const types = (ev: EngineEvent[]) => ev.map((e) => e.type);
const T = (sec: number) => 1_700_000_000_000 + sec * 1000;

describe('RosterEngine', () => {
  it('detects join and debounced leave, using first-miss time as leave time', () => {
    const e = mk();
    expect(types(e.ingest([{ name: 'Rahim' }], T(0)))).toEqual(['join']);
    expect(e.ingest([], T(5))).toEqual([]); // 1st miss: no leave yet
    const ev = e.ingest([], T(10)); // 2nd miss: leave
    expect(types(ev)).toEqual(['leave']);
    expect(ev[0]!.occurred_at).toBe(new Date(T(5)).toISOString());
  });

  it('ignores one-snapshot flicker (no fake leave/rejoin)', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim' }], T(0));
    e.ingest([], T(5));
    const ev = e.ingest([{ name: 'Rahim' }], T(10));
    expect(types(ev)).toEqual([]);
    expect(e.getParticipants()).toHaveLength(1);
  });

  it('treats a returning person as the same participant record (rejoin)', () => {
    const e = mk();
    e.ingest([{ name: 'Karim' }], T(0));
    e.ingest([], T(5));
    e.ingest([], T(10)); // left
    const ev = e.ingest([{ name: 'Karim' }], T(60));
    expect(types(ev)).toEqual(['join']);
    expect(e.getParticipants()).toHaveLength(1);
    expect(ev[0]!.participant_id).toBe(e.getParticipants()[0]!.id);
  });

  it('does not merge two people with the same display name', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim', avatar: 'a1' }], T(0));
    const ev = e.ingest([{ name: 'Rahim', avatar: 'a1' }, { name: 'Rahim', avatar: 'a2' }], T(5));
    expect(types(ev)).toEqual(['join']);
    const ps = e.getParticipants();
    expect(ps).toHaveLength(2);
    expect(ps.every((p) => p.confidence === 'uncertain')).toBe(true);
  });

  it('separates identical names with identical avatars when both are present together', () => {
    const e = mk();
    const ev = e.ingest([{ name: 'Rahim' }, { name: 'Rahim' }], T(0));
    expect(types(ev)).toEqual(['join', 'join']);
    expect(e.getParticipants()).toHaveLength(2);
  });

  it('uses a strong device id as high confidence and keeps people apart', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim', deviceId: 'd1' }, { name: 'Rahim', deviceId: 'd2' }], T(0));
    const ps = e.getParticipants();
    expect(ps).toHaveLength(2);
    expect(ps.every((p) => p.confidence === 'high')).toBe(true);
  });

  it('normalizes "(You)" decoration', () => {
    expect(normalizeName('Sajib  Babu (You)')).toBe('sajib babu');
    const e = mk();
    e.ingest([{ name: 'Sajib Babu (You)' }], T(0));
    expect(types(e.ingest([{ name: 'Sajib Babu' }], T(5)))).toEqual([]);
    expect(e.getParticipants()).toHaveLength(1);
  });

  it('ignores unreliable snapshots (closed panel / DOM change) entirely', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim' }], T(0));
    for (let i = 1; i <= 5; i++) expect(e.ingest([], T(i * 5), false)).toEqual([]);
    expect(e.getParticipants()[0]!.active).toBe(true);
  });

  it('partial snapshots record joins but never produce leaves', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim' }], T(0));
    for (let i = 1; i <= 5; i++) expect(e.ingest([], T(i * 5), true, true)).toEqual([]);
    expect(e.getParticipants()[0]!.active).toBe(true);
    expect(types(e.ingest([{ name: 'Karim' }], T(30), true, true))).toEqual(['join']);
  });

  it('emits seen heartbeats only at the configured interval', () => {
    const e = mk();
    e.ingest([{ name: 'Rahim' }], T(0));
    expect(e.ingest([{ name: 'Rahim' }], T(10))).toEqual([]);
    expect(types(e.ingest([{ name: 'Rahim' }], T(31)))).toEqual(['seen']);
  });

  it('survives snapshot/restore (extension restart) without duplicate joins', () => {
    const a = mk();
    a.ingest([{ name: 'Rahim' }], T(0));
    const saved = JSON.parse(JSON.stringify(a.snapshot()));
    const b = mk();
    b.restore(saved);
    expect(b.ingest([{ name: 'Rahim' }], T(10))).toEqual([]);
    expect(b.getParticipants()).toHaveLength(1);
  });

  it('emits meeting_start/meeting_end once and ignores snapshots after end', () => {
    const e = mk();
    expect(types(e.start(T(0)))).toEqual(['meeting_start']);
    expect(e.start(T(1))).toEqual([]);
    expect(types(e.end(T(100)))).toEqual(['meeting_end']);
    expect(e.end(T(101))).toEqual([]);
    expect(e.ingest([{ name: 'Late' }], T(102))).toEqual([]);
  });

  it('gives every event a unique event_id', () => {
    const e = mk();
    const ev = [...e.ingest([{ name: 'A' }, { name: 'B' }], T(0)), ...e.ingest([], T(5)), ...e.ingest([], T(10))];
    expect(new Set(ev.map((x) => x.event_id)).size).toBe(ev.length);
  });
});
