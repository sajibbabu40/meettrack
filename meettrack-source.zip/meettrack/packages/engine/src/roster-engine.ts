export type Confidence = 'high' | 'medium' | 'low' | 'uncertain';
export type EventType = 'meeting_start' | 'join' | 'leave' | 'seen' | 'meeting_end';

/** One participant tile as read from the Meet roster at a single moment. */
export interface RosterEntry {
  name: string;
  /** Meet's own per-participant id attribute, when the DOM exposes it. */
  deviceId?: string | null;
  /** Avatar URL (or hash of it), used only as a supporting signal. */
  avatar?: string | null;
}

export interface TrackedParticipant {
  id: string;
  name: string;
  normName: string;
  deviceId: string | null;
  avatar: string | null;
  confidence: Confidence;
  duplicateName: boolean;
  active: boolean;
  missCount: number;
  firstMissAt: number | null;
  lastSeenAt: number;
  lastHeartbeatAt: number;
}

export interface EngineEvent {
  event_id: string;
  participant_id: string | null;
  type: EventType;
  occurred_at: string;
}

export interface EngineOptions {
  /** Consecutive missed snapshots before a participant is treated as left (debounce). */
  leaveAfterMisses?: number;
  /** Interval between "seen" heartbeats for active participants. */
  seenIntervalMs?: number;
  uuid?: () => string;
}

export interface EngineState {
  participants: TrackedParticipant[];
  started: boolean;
  ended: boolean;
}

const RANK: Record<Confidence, number> = { high: 3, medium: 2, low: 1, uncertain: 0 };

/** Strips Meet decorations like "(You)" / "(Presenting)" and collapses whitespace. */
export function normalizeName(raw: string): string {
  return raw
    .replace(/\((you|presenting|host|guest)\)/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

export class RosterEngine {
  private participants: TrackedParticipant[] = [];
  private started = false;
  private ended = false;
  private readonly leaveAfterMisses: number;
  private readonly seenIntervalMs: number;
  private readonly uuid: () => string;

  constructor(opts: EngineOptions = {}) {
    this.leaveAfterMisses = opts.leaveAfterMisses ?? 2;
    this.seenIntervalMs = opts.seenIntervalMs ?? 30_000;
    this.uuid = opts.uuid ?? (() => crypto.randomUUID());
  }

  start(nowMs: number): EngineEvent[] {
    if (this.started) return [];
    this.started = true;
    return [this.event('meeting_start', null, nowMs)];
  }

  end(nowMs: number): EngineEvent[] {
    if (this.ended) return [];
    this.ended = true;
    return [this.event('meeting_end', null, nowMs)];
  }

  /**
   * Feed one roster snapshot. Pass reliable=false when the roster panel was not
   * readable (closed, DOM changed): the snapshot is then ignored entirely so a
   * glitch never produces fake leave events. Pass partial=true when the snapshot
   * may be incomplete (e.g. only visible video tiles): joins and heartbeats are
   * still recorded, but absence is never treated as a leave.
   */
  ingest(entries: RosterEntry[], nowMs: number, reliable = true, partial = false): EngineEvent[] {
    if (!reliable || this.ended) return [];
    const out: EngineEvent[] = [];
    const claimed = new Set<string>();

    // Names that appear more than once in this very snapshot are ambiguous.
    const snapshotCounts = new Map<string, number>();
    for (const e of entries) {
      const n = normalizeName(e.name);
      snapshotCounts.set(n, (snapshotCounts.get(n) ?? 0) + 1);
    }

    // Entries with a strong id go first so they claim their own record before name matching.
    const ordered = [...entries].sort((a, b) => Number(!!b.deviceId) - Number(!!a.deviceId));

    for (const entry of ordered) {
      const normName = normalizeName(entry.name);
      if (!normName) continue;
      const deviceId = entry.deviceId ?? null;
      const avatar = entry.avatar ?? null;
      const dupInSnapshot = (snapshotCounts.get(normName) ?? 0) > 1;

      let match = this.findMatch(normName, deviceId, avatar, claimed);

      if (!match) {
        match = {
          id: this.uuid(),
          name: entry.name.trim(),
          normName,
          deviceId,
          avatar,
          confidence: 'low',
          duplicateName: false,
          active: false,
          missCount: 0,
          firstMissAt: null,
          lastSeenAt: nowMs,
          lastHeartbeatAt: nowMs,
        };
        this.participants.push(match);
      }
      claimed.add(match.id);

      // Duplicate-name flag is sticky: once two people shared a name, never trust name alone.
      const sameName = this.participants.filter((p) => p.normName === normName);
      if (dupInSnapshot || sameName.length > 1) {
        for (const p of sameName) p.duplicateName = true;
      }
      if (deviceId && !match.deviceId) match.deviceId = deviceId;
      if (avatar && !match.avatar) match.avatar = avatar;
      match.confidence = this.score(match, deviceId, avatar);

      if (!match.active) {
        match.active = true;
        out.push(this.event('join', match.id, nowMs));
        match.lastHeartbeatAt = nowMs;
      } else if (nowMs - match.lastHeartbeatAt >= this.seenIntervalMs) {
        out.push(this.event('seen', match.id, nowMs));
        match.lastHeartbeatAt = nowMs;
      }
      match.missCount = 0;
      match.firstMissAt = null;
      match.lastSeenAt = nowMs;
    }

    // Anyone active but absent from this snapshot: count the miss, leave only after debounce.
    if (partial) return out;
    for (const p of this.participants) {
      if (!p.active || claimed.has(p.id)) continue;
      p.missCount += 1;
      if (p.firstMissAt === null) p.firstMissAt = nowMs;
      if (p.missCount >= this.leaveAfterMisses) {
        p.active = false;
        out.push(this.event('leave', p.id, p.firstMissAt));
        p.missCount = 0;
        p.firstMissAt = null;
      }
    }
    return out;
  }

  getParticipants(): readonly TrackedParticipant[] {
    return this.participants;
  }

  snapshot(): EngineState {
    return {
      participants: this.participants.map((p) => ({ ...p })),
      started: this.started,
      ended: this.ended,
    };
  }

  restore(state: EngineState): void {
    this.participants = state.participants.map((p) => ({ ...p }));
    this.started = state.started;
    this.ended = state.ended;
  }

  private findMatch(
    normName: string,
    deviceId: string | null,
    avatar: string | null,
    claimed: Set<string>,
  ): TrackedParticipant | null {
    // 1. Strong id is decisive.
    if (deviceId) {
      const byId = this.participants.find((p) => p.deviceId === deviceId && !claimed.has(p.id));
      if (byId) return byId;
    }
    // 2. Name candidates, never stealing a record that provably belongs to someone else.
    const candidates = this.participants.filter((p) => {
      if (claimed.has(p.id) || p.normName !== normName) return false;
      if (deviceId && p.deviceId && p.deviceId !== deviceId && p.active) return false;
      if (avatar && p.avatar && p.avatar !== avatar && p.active) return false;
      return true;
    });
    if (candidates.length === 0) return null;
    candidates.sort((a, b) => {
      const avatarA = avatar && a.avatar === avatar ? 1 : 0;
      const avatarB = avatar && b.avatar === avatar ? 1 : 0;
      if (avatarA !== avatarB) return avatarB - avatarA;
      if (a.active !== b.active) return Number(b.active) - Number(a.active);
      return b.lastSeenAt - a.lastSeenAt;
    });
    return candidates[0] ?? null;
  }

  private score(p: TrackedParticipant, deviceId: string | null, avatar: string | null): Confidence {
    let c: Confidence;
    if (deviceId && p.deviceId === deviceId) c = 'high';
    else if (avatar && p.avatar === avatar) c = 'medium';
    else c = 'low';
    if (p.duplicateName && c !== 'high') c = 'uncertain';
    // Never upgrade past what the record already proved, except via a strong id.
    if (RANK[c] > RANK[p.confidence] && c !== 'high' && p.duplicateName) c = p.confidence;
    return c;
  }

  private event(type: EventType, participantId: string | null, atMs: number): EngineEvent {
    return {
      event_id: this.uuid(),
      participant_id: participantId,
      type,
      occurred_at: new Date(atMs).toISOString(),
    };
  }
}
