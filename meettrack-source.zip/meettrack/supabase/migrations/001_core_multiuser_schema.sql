-- Applied to Supabase project "MeetTrack Pro v2" as migration core_multiuser_schema.
create type public.app_role as enum ('user', 'super_admin');
create type public.identity_confidence as enum ('high', 'medium', 'low', 'uncertain');
create type public.attendance_event_type as enum ('meeting_start', 'join', 'leave', 'seen', 'meeting_end');

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text, full_name text,
  role public.app_role not null default 'user',
  is_active boolean not null default true,
  monthly_meeting_limit integer not null default 30 check (monthly_meeting_limit >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();

create or replace function public.is_super_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'super_admin' and is_active); $$;
create or replace function public.is_active_user() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and is_active); $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'));
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.meetings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  client_meeting_id uuid not null, meet_code text not null, title text,
  started_at timestamptz not null, ended_at timestamptz,
  status text not null default 'live' check (status in ('live','ended','interrupted')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (owner_id, client_meeting_id), unique (id, owner_id),
  check (ended_at is null or ended_at >= started_at)
);
create index meetings_owner_started_idx on public.meetings (owner_id, started_at desc);
create trigger meetings_updated_at before update on public.meetings for each row execute function public.set_updated_at();

create table public.participants (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null, meeting_id uuid not null, client_participant_id uuid not null,
  display_name text not null, identity_key text,
  identity_confidence public.identity_confidence not null default 'uncertain',
  identity_signals jsonb not null default '{}'::jsonb,
  needs_review boolean not null default false, reviewed_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (owner_id, client_participant_id), unique (id, owner_id),
  foreign key (meeting_id, owner_id) references public.meetings (id, owner_id) on delete cascade
);
create index participants_meeting_idx on public.participants (meeting_id);
create index participants_owner_name_idx on public.participants (owner_id, display_name);
create trigger participants_updated_at before update on public.participants for each row execute function public.set_updated_at();

create table public.sync_devices (
  id uuid primary key, owner_id uuid not null references public.profiles(id) on delete cascade,
  label text, last_seen_at timestamptz, created_at timestamptz not null default now()
);
create index sync_devices_owner_idx on public.sync_devices (owner_id);

create table public.attendance_events (
  event_id uuid primary key, owner_id uuid not null, meeting_id uuid not null, participant_id uuid,
  event_type public.attendance_event_type not null, occurred_at timestamptz not null,
  device_id uuid references public.sync_devices(id) on delete set null,
  received_at timestamptz not null default now(), payload jsonb not null default '{}'::jsonb,
  foreign key (meeting_id, owner_id) references public.meetings (id, owner_id) on delete cascade,
  foreign key (participant_id, owner_id) references public.participants (id, owner_id) on delete cascade
);
create index attendance_events_meeting_time_idx on public.attendance_events (meeting_id, occurred_at);
create index attendance_events_participant_time_idx on public.attendance_events (participant_id, occurred_at);
create index attendance_events_owner_idx on public.attendance_events (owner_id);

create table public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null, meeting_id uuid not null, participant_id uuid not null,
  joined_at timestamptz not null, left_at timestamptz,
  duration_seconds integer not null default 0 check (duration_seconds >= 0),
  close_reason text check (close_reason in ('left','meeting_ended','last_seen','open')),
  created_at timestamptz not null default now(),
  unique (participant_id, joined_at), check (left_at is null or left_at >= joined_at),
  foreign key (meeting_id, owner_id) references public.meetings (id, owner_id) on delete cascade,
  foreign key (participant_id, owner_id) references public.participants (id, owner_id) on delete cascade
);
create index attendance_sessions_meeting_idx on public.attendance_sessions (meeting_id);
create index attendance_sessions_owner_idx on public.attendance_sessions (owner_id);

create table public.audit_logs (
  id bigint generated always as identity primary key, actor_id uuid, action text not null,
  target_type text, target_id text, details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs (created_at desc);

alter table public.profiles enable row level security;
alter table public.meetings enable row level security;
alter table public.participants enable row level security;
alter table public.sync_devices enable row level security;
alter table public.attendance_events enable row level security;
alter table public.attendance_sessions enable row level security;
alter table public.audit_logs enable row level security;

create policy profiles_select on public.profiles for select to authenticated using (id = (select auth.uid()) or (select public.is_super_admin()));
create policy profiles_update_own on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;

create policy meetings_select on public.meetings for select to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy meetings_insert on public.meetings for insert to authenticated with check (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy meetings_update on public.meetings for update to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user())) with check (owner_id = (select auth.uid()));
create policy meetings_delete on public.meetings for delete to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));

create policy participants_select on public.participants for select to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy participants_insert on public.participants for insert to authenticated with check (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy participants_update on public.participants for update to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user())) with check (owner_id = (select auth.uid()));
create policy participants_delete on public.participants for delete to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));

create policy devices_select on public.sync_devices for select to authenticated using (owner_id = (select auth.uid()));
create policy devices_insert on public.sync_devices for insert to authenticated with check (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy devices_update on public.sync_devices for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
create policy devices_delete on public.sync_devices for delete to authenticated using (owner_id = (select auth.uid()));

create policy events_select on public.attendance_events for select to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy events_insert on public.attendance_events for insert to authenticated with check (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy sessions_select on public.attendance_sessions for select to authenticated using (owner_id = (select auth.uid()) and (select public.is_active_user()));
create policy audit_select on public.audit_logs for select to authenticated using ((select public.is_super_admin()));

revoke all on all tables in schema public from anon;
revoke execute on function public.is_super_admin() from public, anon;
revoke execute on function public.is_active_user() from public, anon;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.is_super_admin() to authenticated;
grant execute on function public.is_active_user() to authenticated;
